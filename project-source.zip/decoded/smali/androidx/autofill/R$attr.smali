.class public final Landroidx/autofill/R$attr;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/autofill/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static alpha:I = 0x7f010001

.field public static font:I = 0x7f01000b

.field public static fontProviderAuthority:I = 0x7f01000c

.field public static fontProviderCerts:I = 0x7f01000d

.field public static fontProviderFetchStrategy:I = 0x7f01000f

.field public static fontProviderFetchTimeout:I = 0x7f010010

.field public static fontProviderPackage:I = 0x7f010011

.field public static fontProviderQuery:I = 0x7f010012

.field public static fontStyle:I = 0x7f010014

.field public static fontVariationSettings:I = 0x7f010015

.field public static fontWeight:I = 0x7f010016

.field public static ttcIndex:I = 0x7f01002c


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
