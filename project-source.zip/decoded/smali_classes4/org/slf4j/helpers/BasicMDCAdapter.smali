.class public Lorg/slf4j/helpers/BasicMDCAdapter;
.super Ljava/lang/Object;
.source "BasicMDCAdapter.java"

# interfaces
.implements Lorg/slf4j/spi/MDCAdapter;


# instance fields
.field private final inheritableThreadLocalMap:Ljava/lang/InheritableThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/InheritableThreadLocal<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field

.field private final threadLocalMapOfDeques:Lorg/slf4j/helpers/ThreadLocalMapOfStacks;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 44
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 46
    new-instance v0, Lorg/slf4j/helpers/ThreadLocalMapOfStacks;

    invoke-direct {v0}, Lorg/slf4j/helpers/ThreadLocalMapOfStacks;-><init>()V

    iput-object v0, p0, Lorg/slf4j/helpers/BasicMDCAdapter;->threadLocalMapOfDeques:Lorg/slf4j/helpers/ThreadLocalMapOfStacks;

    .line 48
    new-instance v0, Lorg/slf4j/helpers/BasicMDCAdapter$1;

    invoke-direct {v0, p0}, Lorg/slf4j/helpers/BasicMDCAdapter$1;-><init>(Lorg/slf4j/helpers/BasicMDCAdapter;)V

    iput-object v0, p0, Lorg/slf4j/helpers/BasicMDCAdapter;->inheritableThreadLocalMap:Ljava/lang/InheritableThreadLocal;

    return-void
.end method


# virtual methods
.method public clear()V
    .locals 1

    .line 108
    iget-object v0, p0, Lorg/slf4j/helpers/BasicMDCAdapter;->inheritableThreadLocalMap:Ljava/lang/InheritableThreadLocal;

    invoke-virtual {v0}, Ljava/lang/InheritableThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    if-eqz v0, :cond_0

    .line 110
    invoke-interface {v0}, Ljava/util/Map;->clear()V

    .line 111
    iget-object p0, p0, Lorg/slf4j/helpers/BasicMDCAdapter;->inheritableThreadLocalMap:Ljava/lang/InheritableThreadLocal;

    invoke-virtual {p0}, Ljava/lang/InheritableThreadLocal;->remove()V

    :cond_0
    return-void
.end method

.method public clearDequeByKey(Ljava/lang/String;)V
    .locals 0

    .line 168
    iget-object p0, p0, Lorg/slf4j/helpers/BasicMDCAdapter;->threadLocalMapOfDeques:Lorg/slf4j/helpers/ThreadLocalMapOfStacks;

    invoke-virtual {p0, p1}, Lorg/slf4j/helpers/ThreadLocalMapOfStacks;->clearDequeByKey(Ljava/lang/String;)V

    return-void
.end method

.method public get(Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 86
    iget-object p0, p0, Lorg/slf4j/helpers/BasicMDCAdapter;->inheritableThreadLocalMap:Ljava/lang/InheritableThreadLocal;

    invoke-virtual {p0}, Ljava/lang/InheritableThreadLocal;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/Map;

    if-eqz p0, :cond_0

    if-eqz p1, :cond_0

    .line 88
    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public getCopyOfContextMap()Ljava/util/Map;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 136
    iget-object p0, p0, Lorg/slf4j/helpers/BasicMDCAdapter;->inheritableThreadLocalMap:Ljava/lang/InheritableThreadLocal;

    invoke-virtual {p0}, Ljava/lang/InheritableThreadLocal;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/Map;

    if-eqz p0, :cond_0

    .line 138
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0, p0}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    return-object v0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public getCopyOfDequeByKey(Ljava/lang/String;)Ljava/util/Deque;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Deque<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 164
    iget-object p0, p0, Lorg/slf4j/helpers/BasicMDCAdapter;->threadLocalMapOfDeques:Lorg/slf4j/helpers/ThreadLocalMapOfStacks;

    invoke-virtual {p0, p1}, Lorg/slf4j/helpers/ThreadLocalMapOfStacks;->getCopyOfDequeByKey(Ljava/lang/String;)Ljava/util/Deque;

    move-result-object p0

    return-object p0
.end method

.method public getKeys()Ljava/util/Set;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 122
    iget-object p0, p0, Lorg/slf4j/helpers/BasicMDCAdapter;->inheritableThreadLocalMap:Ljava/lang/InheritableThreadLocal;

    invoke-virtual {p0}, Ljava/lang/InheritableThreadLocal;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/Map;

    if-eqz p0, :cond_0

    .line 124
    invoke-interface {p0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object p0

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public popByKey(Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    .line 159
    iget-object p0, p0, Lorg/slf4j/helpers/BasicMDCAdapter;->threadLocalMapOfDeques:Lorg/slf4j/helpers/ThreadLocalMapOfStacks;

    invoke-virtual {p0, p1}, Lorg/slf4j/helpers/ThreadLocalMapOfStacks;->popByKey(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public pushByKey(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 154
    iget-object p0, p0, Lorg/slf4j/helpers/BasicMDCAdapter;->threadLocalMapOfDeques:Lorg/slf4j/helpers/ThreadLocalMapOfStacks;

    invoke-virtual {p0, p1, p2}, Lorg/slf4j/helpers/ThreadLocalMapOfStacks;->pushByKey(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public put(Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    if-eqz p1, :cond_1

    .line 74
    iget-object v0, p0, Lorg/slf4j/helpers/BasicMDCAdapter;->inheritableThreadLocalMap:Ljava/lang/InheritableThreadLocal;

    invoke-virtual {v0}, Ljava/lang/InheritableThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    if-nez v0, :cond_0

    .line 76
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 77
    iget-object p0, p0, Lorg/slf4j/helpers/BasicMDCAdapter;->inheritableThreadLocalMap:Ljava/lang/InheritableThreadLocal;

    invoke-virtual {p0, v0}, Ljava/lang/InheritableThreadLocal;->set(Ljava/lang/Object;)V

    .line 79
    :cond_0
    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    .line 72
    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "key cannot be null"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public remove(Ljava/lang/String;)V
    .locals 0

    .line 98
    iget-object p0, p0, Lorg/slf4j/helpers/BasicMDCAdapter;->inheritableThreadLocalMap:Ljava/lang/InheritableThreadLocal;

    invoke-virtual {p0}, Ljava/lang/InheritableThreadLocal;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/Map;

    if-eqz p0, :cond_0

    .line 100
    invoke-interface {p0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    return-void
.end method

.method public setContextMap(Ljava/util/Map;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    if-eqz p1, :cond_0

    .line 147
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0, p1}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    .line 149
    :goto_0
    iget-object p0, p0, Lorg/slf4j/helpers/BasicMDCAdapter;->inheritableThreadLocalMap:Ljava/lang/InheritableThreadLocal;

    invoke-virtual {p0, v0}, Ljava/lang/InheritableThreadLocal;->set(Ljava/lang/Object;)V

    return-void
.end method
